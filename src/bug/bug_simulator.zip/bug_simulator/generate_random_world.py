


import random
import sys

difficulty = int(sys.argv[1])

f = open("random_world.dat", 'w')

f.write("500 400\n")
f.write("10 10\n")

for i in range(difficulty):
  f.write("%d %d\n" % (50*random.randint(1, 7), 50*random.randint(1, 7)))

f.close()
