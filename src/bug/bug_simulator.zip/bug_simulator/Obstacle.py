from livewires import games, color
from random import randrange

class Obstacle(games.Sprite):
    _image = games.load_image("obstacle.gif", transparent = False)

    def __init__(self, left, top):
	super(Obstacle, self).__init__(Obstacle._image, left=left, top=top)
