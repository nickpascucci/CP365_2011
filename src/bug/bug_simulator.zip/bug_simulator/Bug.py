
from livewires import games, color
from random import randrange
from Goal import *
from Obstacle import *
from sys import exit

class Bug(games.Sprite):

    _image = games.load_image("bug.gif", transparent = True)
    speed = 32

    def __init__(self, left, top, goal):
	super(Bug, self).__init__(Bug._image, left=left, top=top)
	self.bumping = False
	self.goal = goal
	self.setup()

    def setup(self):
	pass

    def choose_move(self):
        return (1, 1)

    def check_legal(self, dx, dy):
	self.x += dx
	self.y += dy
        if len(self.overlapping_sprites) > 0:
	    if type(self.overlapping_sprites[0]) == Goal:
		print "GOOOOOOOOOOOAAAAAAAAAALLLLLLLLLLLLLLL!!!!!!!!!!"
		exit(0)

	    else:
		self.bumping = True
		print "BONK"
		self.x -= dx
		self.y -= dy
		return False

	self.x -= dx
	self.y -= dy
	self.bumping = False
	return True

    def update(self):
        self.dx, self.dy = self.choose_move()

	if not self.check_legal(self.dx, self.dy):
	    self.dx = 0
	    self.dy = 0
	    self.bumping = True




