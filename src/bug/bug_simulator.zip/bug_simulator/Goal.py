from livewires import games, color
from random import randrange

class Goal(games.Sprite):
    _image = games.load_image("goal.gif", transparent = False)

    def __init__(self, left, top):
	super(Goal, self).__init__(Goal	._image, left=left, top=top)

