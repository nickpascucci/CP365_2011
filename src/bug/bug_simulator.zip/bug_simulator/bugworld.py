import sys
from livewires import games, color
from random import randrange
games.init(screen_width = 640, screen_height = 480, fps = 50)	
from MyBug import *
from Goal import *
from Obstacle import *


wall_image = games.load_image("background.png", transparent = False)
games.screen.background = wall_image

def load_world(world_file):
    f = open(world_file)

    x,y = f.readline().split()
    goalx, goaly = int(x), int(y)
    g = Goal(left=goalx, top=goaly)
    games.screen.add(g)

    x,y = f.readline().split()
    bugx, bugy = int(x), int(y)
    b = MyBug(left=bugx, top=bugy, goal=g)
    games.screen.add(b)

    for line in f:
        tokens = line.split()
	print tokens
	o = Obstacle(left=int(tokens[0]), top=int(tokens[1]))
	games.screen.add(o)

load_world(sys.argv[1])
games.screen.mainloop()




