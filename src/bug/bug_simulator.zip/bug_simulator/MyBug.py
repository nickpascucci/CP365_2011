
from livewires import games, color
import random
from Goal import *
from Bug import *

# Environmental inputs:
#   Am I bumping something?  self.bumping boolean
#   Where is the goal?       self.goal.x, self.goal.y

# Choose a next move by returning deltas for x and y
#   Move down and to the right:  (1, 1)
#   Move directly left:          (-1, 0)
#   Move up:                     (0, -1)
#   Go crazy:                    (1-2*random.random(), 1-2*random.random())

class MyBug(Bug):

    def setup(self):
	pass

    def choose_move(self):
	if not self.bumping:
        	return (1, 1)
	else:
		return (1-2*random.random(), 1-2*random.random())





